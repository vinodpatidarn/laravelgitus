<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Common_model  extends CI_Model{
public function __construct()
    {
     parent::__construct();
     $this->load->database();
     $this->load->library('session');
    }
 public function userlogin($table,$data){
  $username = $data['username'];       
  $pass = $data['password'];
  //print_r($username);
         
         $query = $this->db->query("SELECT * FROM user_login WHERE `email` ='$username' AND `pass` ='$pass'");
         if($query->num_rows() > '0'){
           $username = '';
           $id= '';
           foreach($query->result() as $values){
             $username = $values->name;
              $id = $values->id; 
           }
           $array = array(
               
                 'username' => $username,
                  'id' => $id
           );
           $this->session->set_userdata('userdata',$array); 
          print_r('success');
         }else{
           print_r('failed');
         }
      }
}



?>