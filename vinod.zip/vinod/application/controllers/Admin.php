<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin  extends CI_Controller{
  public function __construct()
    {
    parent::__construct();
    $this->load->library('email', 'session');
    $this->load->helper('url'); 
    $this->load->model('Common_model');
    $this->load->library('session');
    }

  public function index(){ 
    if(null == $this->session->userdata('userdata')){
       $this->load->view('login');
    }else{
      header('location:http://localhost/vinod/index.php/Admin/dashboard');
    }
  }
  public function userlogin(){
    $data['userdata'] = $this->input->post();
    $data['check_login'] = $this->Common_model->userlogin('user',$data['userdata']);

  }
   
  public function dashboard(){
    // print_r( $this->session->has_userdata('userdata'));
       if(null !== $this->session->userdata('userdata')){
        $this->load->view('dashboard');
   }else{
    header('location:http://localhost/vinod/index.php/Admin/index');
   }  
    
  }
  public function logout(){
    if(null !== $this->session->userdata('userdata')){
      $this->session->sess_destroy('userdata');
      // print_r($this->session->userdata());
       header('location:http://localhost/vinod/index.php/Admin/index');
}else{
 header('location:http://localhost/vinod/index.php/Admin/index');
}  
 
}
 public function php_catergory(){
    if(null !== $this->session->userdata('userdata')){
       $this->load->view('php_catergory');
}else{
 header('location:http://localhost/vinod/index.php/Admin/index');
} 
} 
public function cat_insert(){
    if(null !== $this->session->userdata('userdata')){
      print_r($this->input->post());
      //$data['insert'] = $this->Common_model->cat_insert();
}else{
 header('location:http://localhost/vinod/index.php/Admin/index');
}  
 
}
}




?>