<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin  extends CI_Controller{
  public function __construct()
    {
    parent::__construct();
    $this->load->library('email', 'session');
    $this->load->helper('url'); 
    $this->load->model('Common_model');
    }

  public function index(){ 
  $this->load->view('login');
  }
  public function userlogin(){
    $data['userdata'] = $this->input->post();
    $data['check_login'] = $this->Common_model->userlogin('user',$data['userdata']);

  }
   
  public function dashboard(){
       if(null !== $this->session->userdata()){
        $this->load->view('dashboard');
   }else{
    header('location:http://localhost/login/index.php/Admin/index/');
   }  
    
  }
  public function logout(){
    if(null !== $this->session->userdata()){
      $this->session->sess_destroy();
       print_r($this->session->userdata());
}else{
 header('location:http://localhost/login/index.php/Admin/index/');
}  
 
}
}




?>