<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Common_model  extends CI_Model{
public function __construct()
    {
     parent::__construct();
     $this->load->database();
    }
 public function userlogin($table,$data){
  $username = $data['username'];       
  $pass = $data['password'];
  //print_r($username);
         
         $query = $this->db->query("SELECT * FROM user WHERE `usernm` ='$username' AND `pass` ='$pass'");
         if($query->num_rows() > '0'){
           $username = '';
           $id= '';
           foreach($query->result() as $values){
             $username = $values->usernm;
              $id = $values->id; 
           }
           $array = array(
               
                 'username' => $username,
                  'id' => $id
           );
           $this->session->set_userdata('userdata',$array);
           print_r('success');
         }else{
           print_r('failed');
         }
      }
}



?>